//
//  ProductsTableViewCell.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit
protocol ProductDelegate : AnyObject {
    func reloadData(productData : ProductInCartModel)
    func removeProduct(productData: ProductInCartModel)
    func updateCart(productData: [ProductInCartModel], index:Int)
}

class ProductsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellBackgroundView: UIView!
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var produvtNameView: UIView!
    @IBOutlet weak var wishListButton: UIButton!
    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var productPrice: UILabel!
    @IBOutlet weak var discountPrice: UILabel!
    @IBOutlet weak var buttonReduce: UIButton!
    @IBOutlet weak var countTf: UITextField!
    @IBOutlet weak var buttonStackView: UIStackView!
    
    @IBOutlet weak var addReduceStackView: UIStackView!
    @IBOutlet weak var addToCartStackView: UIStackView!
    @IBOutlet weak var buttonAdd: UIButton!
    
    @IBOutlet weak var addtocartButton: UIButton!
    
    var presentationController = UIViewController()
    
    
    
    var delegate:ProductDelegate?
    var index = 0
    var indexCart = 0
    var productsCountArray = [ProductInCartModel]()
    var category = ""
    var productArray = [Product]()
    override func awakeFromNib() {
        super.awakeFromNib()
        self.prepareCellView()
        // Initialization code
    }
    func prepareCellView(){
        self.addToCartStackView.layer.cornerRadius = 5
        self.cellBackgroundView.layer.cornerRadius = 10
        self.countTf.text = "0"
    }
    func setUpCellCart(data:[ProductInCartModel] , index:Int){
        self.productsCountArray = data
        switch data[index].category {
        case "Dairy":
            self.productImageView.image = UIImage(named: "pdairy")
        case "Tea":
            self.productImageView.image = UIImage(named: "ptea")
        case "Munchies":
            self.productImageView.image = UIImage(named: "pmunchis")
        case "Cold drinks":
            self.productImageView.image = UIImage(named: "pcolddrinks")
        case "Coffee":
            self.productImageView.image = UIImage(named: "pcoffee")
        case "Fruits":
            self.productImageView.image = UIImage(named: "pfruits")
        case "Cleaning":
            self.productImageView.image = UIImage(named: "pcleaning")
        case "Pet Care":
            self.productImageView.image = UIImage(named: "ppets")
        default:
            break
        }
        self.countTf.text = "\(data[index].qty ?? 0)"
        self.productName.text = data[index].name
        self.productPrice.text = data[index].description
        self.discountPrice.text = "\(data[index].price ?? 0)"
    }
    func setUpcell(data:[Product], index:Int, category:String){
        self.productArray = data
        switch category {
        case "Dairy":
            self.productImageView.image = UIImage(named: "pdairy")
        case "Tea":
            self.productImageView.image = UIImage(named: "ptea")
        case "Munchies":
            self.productImageView.image = UIImage(named: "pmunchis")
        case "Cold drinks":
            self.productImageView.image = UIImage(named: "pcolddrinks")
        case "Coffee":
            self.productImageView.image = UIImage(named: "pcoffee")
        case "Fruits":
            self.productImageView.image = UIImage(named: "pfruits")
        case "Cleaning":
            self.productImageView.image = UIImage(named: "pcleaning")
        case "Pet Care":
            self.productImageView.image = UIImage(named: "ppets")
        default:
            break
        }
        self.category = category
        self.productName.text = data[index].name
        self.productPrice.text = data[index].description
        //self.countTf.text = "\(data[index].description)"
        self.discountPrice.text = "\(data[index].price)"
    }
    
    @IBAction func addAction(_ sender: Any) {
        self.buttonAdd.tag = self.indexCart
        self.addProduct {
            print("added")
        }
    }
    
    @IBAction func subtractAction(_ sender: Any) {
        self.buttonReduce.tag = self.indexCart
        self.subtractProduct {
            print("subtracted")
        }
    }
    
    
    @IBAction func addtocartAction(_ sender: Any) {
        self.addtocartButton.tag = self.index
        addtocartButton.isSelected = !addtocartButton.isSelected
        let productObj = ProductInCartModel()
        if addtocartButton.isSelected{
            self.addtocartButton.setTitle("Go to cart", for: .normal)
            self.addtocartButton.backgroundColor = UIColor(named: "pending")
            productObj.price = self.productArray[self.index].price
            productObj.name = self.productArray[self.index].name
            productObj.pid = self.productArray[self.index].pid
            productObj.description = self.productArray[self.index].description
            productObj.category = self.category
            productObj.inventoryCount = self.productArray[self.index].inventoryCount - 1
            productObj.qty = 1
            self.delegate?.reloadData(productData: productObj)
        } else {
            self.addtocartButton.setTitle("Add to cart", for: .normal)
            self.addtocartButton.backgroundColor = UIColor(named: "AppTheme")
            productObj.price = self.productArray[self.index].price
            productObj.name = self.productArray[self.index].name
            productObj.pid = self.productArray[self.index].pid
            productObj.description = self.productArray[self.index].description
            productObj.category = self.category
            productObj.inventoryCount = self.productArray[self.index].inventoryCount + 1
            productObj.qty = 0
            self.delegate?.removeProduct(productData: productObj)
        }

    }
    func addProduct(completion: @escaping () -> Void){
        let newCount = (Int(self.countTf.text ?? "") ?? 0) + 1
        self.countTf.text = "\(newCount)"
        self.productsCountArray[self.indexCart].qty = newCount
        self.delegate?.updateCart(productData: self.productsCountArray, index: self.indexCart)
    }
    
    func subtractProduct(completion: @escaping () -> Void){
        let newCount = (Int(self.countTf.text ?? "") ?? 0) - 1
        self.countTf.text = "\(newCount)"
        self.productsCountArray[self.indexCart].qty = newCount
        self.delegate?.updateCart(productData: self.productsCountArray, index: self.indexCart)
    }
}

//
//  CatogriesTableViewCell.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit

class CatogriesTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var catogeryImage: UIImageView!
    
    @IBOutlet weak var catogeryName: UILabel!
    
    @IBOutlet weak var cellButton: UIButton!
    @IBOutlet weak var catogryOffers: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.mainView.layer.cornerRadius = 10
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setupCell(dataArr:[Category], index: Int){
        self.catogeryName.text = dataArr[index].category
        switch dataArr[index].category {
        case "Dairy":
            self.catogeryImage.image = UIImage(named: "Dairy")
            self.catogryOffers.text = "Get 30% off on Amul dairy products"
        case "Tea":
            self.catogeryImage.image = UIImage(named: "Tea")
            self.catogryOffers.text = "Buy 1 Get 1 on Tata tea 30gm pack"
        case "Munchies":
            self.catogeryImage.image = UIImage(named: "Munchis")
            self.catogryOffers.text = "Buy 1 Get 1 on Good Day small pack"
        case "Cold drinks":
            self.catogeryImage.image = UIImage(named: "ColdDrinks")
            self.catogryOffers.text = "Everything @ 39rs"
        case "Coffee":
            self.catogeryImage.image = UIImage(named: "Tea")
            self.catogryOffers.text = "Buy 1 Get 1 on Nescafe 30gm pack"
        case "Fruits":
            self.catogeryImage.image = UIImage(named: "Fruits")
            self.catogryOffers.text = "Fresh fruits and vegetables"
        case "Cleaning":
            self.catogeryImage.image = UIImage(named: "Cleaning")
            self.catogryOffers.text = "Get 15rs off on vim gel"
        case "Pet Care":
            self.catogeryImage.image = UIImage(named: "Pet")
            self.catogryOffers.text = "Get 5% off on pet toys"
        default:
            break
        }
    }
}

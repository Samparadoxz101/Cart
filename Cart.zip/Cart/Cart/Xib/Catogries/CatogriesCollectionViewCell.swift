//
//  CatogriesCollectionViewCell.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 22/07/23.
//

import UIKit

class CatogriesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cellBackgroundView: UIView!
    @IBOutlet weak var iconImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

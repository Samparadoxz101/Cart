//
//  CartVM.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import Foundation

class CartVM: NSObject {
    
    func getOrderDetails() -> [Category]{
        
        // Sample JSON data (replace this with your actual JSON data)
        let jsonData = JsonManager.shared.jsonString.data(using: .utf8)!
        var dataArry = [Category]()
        do {
            // Parse JSON data into Swift objects
            let decoder = JSONDecoder()
            let dummyData = try decoder.decode([Category].self, from: jsonData)
            dataArry = dummyData
            // Access the data
            for category in dummyData {
                print("Category: \(category.category)")
                for product in category.products {
                    print(" - Product: \(product.name), Price: \(product.price), Inventory Count: \(product.inventoryCount)")
                }
            }
        } catch {
            print("Error: \(error)")
        }
        return dataArry
    }
}

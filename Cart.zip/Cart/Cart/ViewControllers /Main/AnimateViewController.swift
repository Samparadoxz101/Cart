//
//  AnimateViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 22/07/23.
//

import UIKit

class AnimateViewController: BaseVC {
    
    @IBOutlet weak var splashImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let cricket101 = UIImage.gifImageWithName("cart")
        self.splashImage.image = cricket101
        self.navigationController?.isNavigationBarHidden = true
    }
    override func viewDidAppear(_ animated: Bool)
    {
        super.viewDidAppear(animated)
        self.startAnimation()
    }
    
    // MARK: - Animation Delay
    func startAnimation()
    {
        Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.performOperation(sender:)), userInfo: nil, repeats: false)
    }
    // MARK: - Api calling
    @objc func performOperation(sender : Timer){
        let vm = CartVM()
        let dataArray = vm.getOrderDetails()
        self.splashTimeOut(arrData: dataArray)
    }
    func splashTimeOut(arrData:[Category]){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let CatogryVC = storyboard.instantiateViewController(withIdentifier: "CatogriesViewController") as! CatogriesViewController
        CatogryVC.allData = arrData
        self.navigationController?.pushViewController(CatogryVC, animated: true)
    }
}



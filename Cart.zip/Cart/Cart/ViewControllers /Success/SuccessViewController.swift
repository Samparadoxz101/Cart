//
//  SuccessViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit

class SuccessViewController: BaseVC {
    
    
    @IBOutlet weak var alertBackground: UIView!
    @IBOutlet weak var successImage: UIImageView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var buttonToCategory: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.alertBackground.layer.cornerRadius = 10
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Orderaction(_ sender: Any) {
        let vm = CartVM()
        let dataArray = vm.getOrderDetails()
        self.splashTimeOut(arrData: dataArray)
    }
    
    func splashTimeOut(arrData:[Category]){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let CatogryVC = storyboard.instantiateViewController(withIdentifier: "CatogriesViewController") as! CatogriesViewController
        CatogryVC.allData = arrData
        self.navigationController?.pushViewController(CatogryVC, animated: true)
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

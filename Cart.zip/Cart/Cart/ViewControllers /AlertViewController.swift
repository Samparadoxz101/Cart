//
//  AlertViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit

class AlertViewController: BaseVC {

    @IBOutlet var screenBackground: UIView!
    @IBOutlet weak var popupView: UIView!
    @IBOutlet weak var alertString: UILabel!
    var qtyString = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.handleTap(_:)))
        tap.delegate = self
        self.screenBackground.addGestureRecognizer(tap)
        self.prepareView()
        // Do any additional setup after loading the view.
    }
    func prepareView(){
        self.popupView.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        self.popupView.layer.cornerRadius = 15
        self.alertString.text = "Sorry, only \(qtyString) Quantites of this product is currently in stock!"
    }
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

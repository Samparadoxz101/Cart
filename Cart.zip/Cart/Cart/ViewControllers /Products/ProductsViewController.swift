//
//  ProductsViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit
protocol ProductScreenDelegate : AnyObject {
    func reloadData(productData : [ProductInCartModel])
}
class ProductsViewController: BaseVC {
    
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var categoryName: UILabel!
    @IBOutlet weak var itemCountLabel: UILabel!
    @IBOutlet weak var producttableView: UITableView!
    @IBOutlet weak var cartView: UIView!
    @IBOutlet weak var itemsCount: UILabel!
    @IBOutlet weak var qtyLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var checkoutButton: UIButton!
    var delegate:ProductScreenDelegate?
    var category = ""
    var productsArray = [Product]()
    var arrcartCount = [ProductInCartModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareView()
        // Do any additional setup after loading the view.
    }
    
    func prepareView(){
        self.cartView.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        self.cartView.layer.cornerRadius = 10
        if arrcartCount.count > 0 {
            self.cartView.isHidden = false
        } else {
            self.cartView.isHidden = true
        }
        self.categoryName.text = self.category
        self.checkoutButton.layer.cornerRadius = 5
        self.prepareTableView()
    }
    func prepareTableView(){
        self.producttableView.backgroundColor = .clear
        self.producttableView.delegate = self
        self.producttableView.dataSource = self
        self.producttableView.register(UINib(nibName: "ProductsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductsTableViewCell")
        self.producttableView.reloadData()
        self.producttableView.layoutIfNeeded()
        self.updateCartValues()
    }
    func updateCartValues(){
        var finalAmount = 0
        let totalItem = arrcartCount.count
        for data in arrcartCount{
            finalAmount += Int((Double(data.qty ?? 0) * (data.price ?? 0)))
        }
        self.amountLabel.text = "Total Amount: \(finalAmount)R"
        self.qtyLabel.text = "Total Item(s):\(totalItem)"
    }
    
    @IBAction func cartAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let CartVC = storyboard.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
        CartVC.arrcartCount = arrcartCount
        self.navigationController?.pushViewController(CartVC, animated: true)
    }
    @IBAction func backAction(_ sender: Any) {
        self.delegate?.reloadData(productData: self.arrcartCount)
        self.navigationController?.popViewController(animated: true)
    }
}
extension ProductsViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productsArray.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell =  tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell") as? ProductsTableViewCell else {
            return ProductsTableViewCell()
        }
        cell.delegate = self
        cell.index = indexPath.row
        cell.addReduceStackView.isHidden = true
        cell.buttonAdd.isUserInteractionEnabled = false
        cell.buttonReduce.isUserInteractionEnabled = false
        cell.setUpcell(data: productsArray, index: indexPath.row, category: self.category)
        return cell
    }
}

extension ProductsViewController: CartOrderDelegate {
    func reloadData(data: [ProductInCartModel]) {
        self.arrcartCount = data
    }
}
extension ProductsViewController: ProductDelegate {
    func updateCart(productData: [ProductInCartModel], index: Int) {
        print("Hello")
    }
    
    func removeProduct(productData: ProductInCartModel) {
        self.arrcartCount.removeAll{
            $0.pid == productData.pid
        }
        if self.arrcartCount.count > 0 {
            self.cartView.isHidden = false
            var amount = 0
            let totalItems = self.arrcartCount.count
            for data in arrcartCount {
                amount = Int(Double(amount) + (data.price ?? 0))
            }
            self.amountLabel.text = "Total Amount: \(amount)R"
            self.qtyLabel.text = "Total Item(s): \(totalItems)"
            self.itemCountLabel.text = "\(totalItems) Item(s)"
        } else {
            self.cartView.isHidden = true
        }
    }
    
    func reloadData(productData: ProductInCartModel) {
        self.arrcartCount.append(productData)
        if self.arrcartCount.count > 0 {
            self.cartView.isHidden = false
            var amount = 0
            let totalItems = self.arrcartCount.count
            for data in arrcartCount {
                amount = Int(Double(amount) + (data.price ?? 0))
            }
            self.amountLabel.text = "Total Amount: \(amount)R"
            self.qtyLabel.text = "Total Item(s): \(totalItems)"
            self.itemCountLabel.text = "\(totalItems) Item(s)"
        } else {
            self.cartView.isHidden = true
        }
    }
}

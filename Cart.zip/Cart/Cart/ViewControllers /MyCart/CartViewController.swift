//
//  CartViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import UIKit
protocol CartOrderDelegate: AnyObject{
    func reloadData(data:[ProductInCartModel])
}
class CartViewController: BaseVC {
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var categoryName: UILabel!
    @IBOutlet weak var itemCountLabel: UILabel!
    @IBOutlet weak var producttableView: UITableView!
    @IBOutlet weak var cartView: UIView!
    @IBOutlet weak var itemsCount: UILabel!
    @IBOutlet weak var qtyLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var checkoutButton: UIButton!
    
    
    var delegate:CartOrderDelegate?
    var category = ""
    var productsArray = [Product]()
    var arrcartCount = [ProductInCartModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareView()
        // Do any additional setup after loading the view.
    }
    func prepareView(){
        self.cartView.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        self.cartView.layer.cornerRadius = 10
        self.cartView.isHidden = false
        self.checkoutButton.layer.cornerRadius = 5
        self.prepareTableView()
        self.updateCartValues()
    }
    func updateCartValues(){
        var finalAmount = 0
        let totalItem = arrcartCount.count
        for data in arrcartCount{
            finalAmount += Int((Double(data.qty ?? 0) * (data.price ?? 0)))
        }
        self.amountLabel.text = "Total Amount: \(finalAmount)R"
        self.qtyLabel.text = "Total Item(s):\(totalItem)"
    }
    func prepareTableView(){
        self.producttableView.backgroundColor = .clear
        self.producttableView.delegate = self
        self.producttableView.dataSource = self
        self.producttableView.register(UINib(nibName: "ProductsTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductsTableViewCell")
        self.producttableView.reloadData()
        self.producttableView.layoutIfNeeded()
    }
    
    @IBAction func placeOrderAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let successVC = storyboard.instantiateViewController(withIdentifier: "SuccessViewController") as! SuccessViewController
        successVC.modalPresentationStyle = .overFullScreen
        self.present(successVC, animated: true)
    }
    @IBAction func backAction(_ sender: Any) {
        self.delegate?.reloadData(data: self.arrcartCount)
        self.navigationController?.popViewController(animated: true)
    }
}
extension CartViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrcartCount.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell =  tableView.dequeueReusableCell(withIdentifier: "ProductsTableViewCell") as? ProductsTableViewCell else {
            return ProductsTableViewCell()
        }
        cell.delegate = self
        cell.indexCart = indexPath.row
        cell.addtocartButton.isHidden = true
        cell.setUpCellCart(data: arrcartCount, index: indexPath.row)
        return cell
    }
}
    
extension CartViewController:ProductDelegate {
    func updateCart(productData: [ProductInCartModel], index: Int) {
        if (productData[index].qty ?? 0) > (productData[index].inventoryCount ?? 0) {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let alertVC = storyboard.instantiateViewController(withIdentifier: "AlertViewController") as! AlertViewController
            alertVC.qtyString = "\(productData[index].inventoryCount ?? 0)"
            alertVC.modalPresentationStyle = .overFullScreen
            self.present(alertVC, animated: true)
            //self.navigationController?.pushViewController(alertVC, animated: true)
        } else {
            self.arrcartCount = productData
            if arrcartCount[index].qty == 0 {
                arrcartCount.removeAll{
                    $0.qty == 0
                }
            }
            updateCartValues()
            self.producttableView.reloadData()
        }
    }
        
    func reloadData(productData: ProductInCartModel) {
        print("hello")
    }
    
    func removeProduct(productData: ProductInCartModel) {
        print("olleh")
    }
    
    
}

//
//  CatogriesViewController.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 22/07/23.
//

import UIKit

class CatogriesViewController: BaseVC {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userProfileImage: UIImageView!
    @IBOutlet weak var catogriesTableView: UITableView!
    @IBOutlet weak var cartView: UIView!
    @IBOutlet weak var itemsCount: UILabel!
    @IBOutlet weak var qtyLabel: UILabel!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var checkoutButton: UIButton!
    
    var cartdata = [ProductInCartModel]()
    var allData = [Category]()
    var productsArray = [Product]()
    var FilteredData = [Category]()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.prepareView()
        self.prepareTableView()
        // Do any additional setup after loading the view.
    }
    
    func prepareView(){
        self.cartView.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        self.cartView.layer.cornerRadius = 10
        if self.productsArray.count > 0 {
            self.cartView.isHidden = false
        } else {
            self.cartView.isHidden = true
        }
        self.checkoutButton.layer.cornerRadius = 5
    }
    func prepareTableView(){
        self.catogriesTableView.backgroundColor = .clear
        self.catogriesTableView.delegate = self
        self.catogriesTableView.dataSource = self//register(UINib(nibName: "SelfLeaveManagementTableViewCell", bundle: nil), forCellReuseIdentifier: "SelfLeaveManagementTableViewCell")
        self.catogriesTableView.register(UINib(nibName: "CatogriesTableViewCell", bundle: nil), forCellReuseIdentifier: "CatogriesTableViewCell")
        self.catogriesTableView.reloadData()
        self.catogriesTableView.layoutIfNeeded()
    }
    
    @IBAction func cartAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let CartVC = storyboard.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
        CartVC.arrcartCount = cartdata
        self.navigationController?.pushViewController(CartVC, animated: true)
    }
}
extension CatogriesViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allData.count
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell =  tableView.dequeueReusableCell(withIdentifier: "CatogriesTableViewCell") as? CatogriesTableViewCell else {
            return CatogriesTableViewCell()
        }
        
        cell.setupCell(dataArr: allData, index: indexPath.row)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let ProductVC = storyboard.instantiateViewController(withIdentifier: "ProductsViewController") as! ProductsViewController
        ProductVC.productsArray = allData[indexPath.row].products
        ProductVC.category = allData[indexPath.row].category
        ProductVC.delegate = self
        ProductVC.arrcartCount = self.cartdata
        self.navigationController?.pushViewController(ProductVC, animated: true)
    }
    
}
extension CatogriesViewController:ProductScreenDelegate{
    func reloadData(productData: [ProductInCartModel]) {
        self.cartdata = productData
        if self.cartdata.count > 0 {
            self.cartView.isHidden = false
        }
        if self.cartdata.count > 0 {
            self.cartView.isHidden = false
            var amount = 0
            let totalItems = self.cartdata.count
            for data in cartdata {
                amount = Int(Double(amount) + (data.price ?? 0))
            }
            self.amountLabel.text = "Total Amount: \(amount)"
            self.qtyLabel.text = "Total Item(s): \(totalItems)"
        } else {
            self.cartView.isHidden = true
        }
    }
}

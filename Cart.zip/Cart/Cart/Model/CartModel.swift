//
//  CartModel.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import Foundation

import Foundation

// Define the Product model
struct Product: Codable {
    var name: String
    var description: String
    var image: String
    var pid: Int
    var price: Double
    var inventoryCount: Int // Renamed to inventoryCount to follow Swift naming conventions
}

// Define the Category model that contains an array of products
struct Category: Codable {
    var category: String
    var categoryid: Int
    var products: [Product]
}

// Define the main model that holds an array of categories
struct DummyData: Codable {
    var categories: [Category]
}

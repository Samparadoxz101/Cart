//
//  ProductInCartModel.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import Foundation

class ProductInCartModel {
    
    var name: String?
    var description: String?
    var image: String?
    var pid: Int?
    var price: Double?
    var qty: Int?
    var inventoryCount: Int?
    var category:String?
    
    init(){}
}

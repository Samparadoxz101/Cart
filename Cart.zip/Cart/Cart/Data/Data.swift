//
//  Data.swift
//  Cart
//
//  Created by Shivam Vishwakarma on 23/07/23.
//

import Foundation

class JsonManager {
    static let shared = JsonManager()

    let jsonString: String

    private init() {
        // Replace this JSON string with your desired JSON data
        jsonString = """
        [
          {
            "category": "Dairy",
            "categoryid":1,
            "products": [
              {
                "name": "Milk",
                "description": "Fresh cow's milk",
                "image": "milk.jpg",
                "pid": 11,
                "price": 30,
                "inventoryCount": 10
              },
              {
                "name": "Cheese",
                "description": "Cheddar cheese",
                "image": "cheese.jpg",
                "pid": 12,
                "price": 80,
                "inventoryCount": 10
              },
              {
                "name": "Yogurt",
                "description": "Greek yogurt",
                "image": "yogurt.jpg",
                "pid": 13,
                "price": 100,
                "inventoryCount": 10
              },
              {
                "name": "Butter",
                "description": "Salted butter",
                "image": "butter.jpg",
                "pid": 14,
                "price": 35,
                "inventoryCount": 10
              },
              {
                "name": "Eggs",
                "description": "Farm-fresh eggs",
                "image": "eggs.jpg",
                "pid": 15,
                "price": 70,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Munchies",
            "categoryid":2,
            "products": [
              {
                "name": "Potato Chips",
                "description": "Classic potato chips",
                "image": "chips.jpg",
                "pid": 21,
                "price": 20,
                "inventoryCount": 10
              },
              {
                "name": "Popcorn",
                "description": "Salted popcorn",
                "image": "popcorn.jpg",
                "pid": 22,
                "price": 15,
                "inventoryCount": 10
              },
              {
                "name": "Pretzels",
                "description": "Baked pretzels",
                "image": "pretzels.jpg",
                "pid": 23,
                "price": 50,
                "inventoryCount": 10
              },
              {
                "name": "Chocolate Bar",
                "description": "Milk chocolate bar",
                "image": "chocolate.jpg",
                "pid": 24,
                "price": 100,
                "inventoryCount": 10
              },
              {
                "name": "Trail Mix",
                "description": "Assorted trail mix",
                "image": "trail_mix.jpg",
                "pid": 25,
                "price": 240,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Cold drinks",
            "categoryid":3,
            "products": [
              {
                "name": "Cola",
                "description": "Classic cola",
                "image": "cola.jpg",
                "pid": 31,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Lemonade",
                "description": "Refreshing lemonade",
                "image": "lemonade.jpg",
                "pid": 32,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Iced Tea",
                "description": "Sweetened iced tea",
                "image": "iced_tea.jpg",
                "pid": 33,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Sparkling Water",
                "description": "Flavored sparkling water",
                "image": "sparkling_water.jpg",
                "pid": 34,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Energy Drink",
                "description": "High-energy drink",
                "image": "energy_drink.jpg",
                "pid": 35,
                "price": 40,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Tea",
            "categoryid":4,
            "products": [
              {
                "name": "Black Tea",
                "description": "Classic black tea",
                "image": "black_tea.jpg",
                "pid": 41,
                "price": 60,
                "inventoryCount": 10
              },
              {
                "name": "Green Tea",
                "description": "Refreshing green tea",
                "image": "green_tea.jpg",
                "pid": 42,
                "price": 60,
                "inventoryCount": 10
              },
              {
                "name": "Chai Tea",
                "description": "Spiced chai tea",
                "image": "chai_tea.jpg",
                "pid": 43,
                "price": 20,
                "inventoryCount": 10
              },
              {
                "name": "Earl Grey",
                "description": "Earl grey tea",
                "image": "earl_grey_tea.jpg",
                "pid": 44,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Herbal Tea",
                "description": "Various herbal tea",
                "image": "herbal_tea.jpg",
                "pid": 45,
                "price": 40,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Coffee",
            "categoryid":5,
            "products": [
              {
                "name": "Black Coffee",
                "description": "Classic black coffee",
                "image": "black_coffee.jpg",
                "pid": 511,
                "price": 30,
                "inventoryCount": 10
              },
              {
                "name": "Latte",
                "description": "Creamy latte",
                "image": "latte.jpg",
                "pid": 52,
                "price": 100,
                "inventoryCount": 10
              },
              {
                "name": "Espresso",
                "description": "Strong espresso",
                "image": "espresso.jpg",
                "pid": 53,
                "price": 200,
                "inventoryCount": 10
              },
              {
                "name": "Cappuccino",
                "description": "Frothy cappuccino",
                "image": "cappuccino.jpg",
                "pid": 54,
                "price": 40,
                "inventoryCount": 10
              },
              {
                "name": "Iced Coffee",
                "description": "Chilled iced coffee",
                "image": "iced_coffee.jpg",
                "pid": 55,
                "price": 20,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Fruits",
            "categoryid":6,
            "products": [
              {
                "name": "Apple",
                "description": "Fresh red apple",
                "image": "apple.jpg",
                "pid": 61,
                "price": 180,
                "inventoryCount": 10
              },
              {
                "name": "Banana",
                "description": "Yellow banana",
                "image": "banana.jpg",
                "pid": 62,
                "price": 70,
                "inventoryCount": 10
              },
              {
                "name": "Orange",
                "description": "Juicy orange",
                "image": "orange.jpg",
                "pid": 63,
                "price": 70,
                "inventoryCount": 10
              },
              {
                "name": "Grapes",
                "description": "Seedless grapes",
                "image": "grapes.jpg",
                "pid": 64,
                "price": 100,
                "inventoryCount": 10
              },
              {
                "name": "Watermelon",
                "description": "Sweet watermelon",
                "image": "watermelon.jpg",
                "pid": 65,
                "price": 60,
                "inventoryCount": 10
              }
            ]
          },
          {
            "category": "Cleaning",
            "categoryid":7,
            "products": [
              {
                "name": "All-Purpose Cleaner",
                "description": "Effective all-purpose cleaner",
                "image": "all_purpose_cleaner.jpg",
                "pid": 71,
                "price": 120,
                "inventoryCount": 50
              },
              {
                "name": "Bathroom Cleaner",
                "description": "Powerful bathroom cleaner",
                "image": "bathroom_cleaner.jpg",
                "pid": 72,
                "price": 130,
                "inventoryCount": 40
              },
              {
                "name": "Glass Cleaner",
                "description": "Streak-free glass cleaner",
                "image": "glass_cleaner.jpg",
                "pid": 73,
                "price": 120,
                "inventoryCount": 60
              },
              {
                "name": "Floor Cleaner",
                "description": "Fresh-scented floor cleaner",
                "image": "floor_cleaner.jpg",
                "pid": 74,
                "price": 146,
                "inventoryCount": 70
              },
              {
                "name": "Dishwashing Liquid",
                "description": "Gentle dishwashing liquid",
                "image": "dishwashing_liquid.jpg",
                "pid": 75,
                "price": 115,
                "inventoryCount": 80
              }
            ]
          },
          {
            "category": "Pet Care",
            "categoryid":8,
            "products": [
              {
                "name": "Dog Food",
                "description": "Premium dog food",
                "image": "dog_food.jpg",
                "pid": 81,
                "price": 500,
                "inventoryCount": 10
              },
              {
                "name": "Cat Food",
                "description": "Nutritious cat food",
                "image": "cat_food.jpg",
                "pid": 82,
                "price": 450,
                "inventoryCount": 8
              },
              {
                "name": "Pet Treats",
                "description": "Tasty pet treats",
                "image": "pet_treats.jpg",
                "pid": 83,
                "price": 25,
                "inventoryCount": 10
              },
              {
                "name": "Pet Shampoo",
                "description": "Gentle pet shampoo",
                "image": "pet_shampoo.jpg",
                "pid": 84,
                "price": 200,
                "inventoryCount": 10
              },
              {
                "name": "Pet Toys",
                "description": "Interactive pet toys",
                "image": "pet_toys.jpg",
                "pid": 85,
                "price": 350,
                "inventoryCount": 10
              }
            ]
          }
        ]
        """
    }
}
